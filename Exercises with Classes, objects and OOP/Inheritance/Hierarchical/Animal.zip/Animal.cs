﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hierarchical
{
    public class Animal
    {
        public void Eat()
        {
            Console.WriteLine("eating...");
        }
    }
}
