﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CustomStack
{
    public class StackOfStrings : Stack<string>
    {
        public bool IsEmpty()
        {
            if (this.Count > 0)
            {
                return false;
            }
            return true;
        }
        public Stack<string> AddRange()
        {
            Stack<string> stack = new Stack<string>();
            return stack;
        }
    }
}
